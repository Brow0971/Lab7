from gfxhat import lcd, backlight
import time

backlight.set_all(0, 0, 255)  # Turns the Backlight On
backlight.show()  # Displays the Backlight

lcd.clear()  # Clear the Screen
lcd.show()

# List
ball = [
    [0, 0, 0, 1, 1, 0, 0, 0],
    [0, 0, 1, 1, 1, 1, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 1, 0, 0],
    [0, 0, 0, 1, 1, 0, 0, 0]
]

# Show the ball!
def displayObject(obj, x, y):
    i = 0
    for line in obj:
        j = 0
        for pixel in line:
            lcd.set_pixel(x + j, y + i, pixel)
            j = j + 1
        i = i + 1
    lcd.show()

#erase the ball before bouncing!
def eraseObject(obj, x, y):
    i = 0
    for line in obj:
        j = 0
        for pixel in line:
            lcd.set_pixel(x + j, y + i, 0)
            j = j + 1
        i = i + 1
    lcd.show()

# move object function after erase to prevent pixels after bounce
def moveObject(obj, x, y, vx, vy):
    x = x + vx
    y = y + vy
    return x, y
# formula takes into account length of object to prevent ball going off screen
def checkCollision(obj, x, y, vx, vy, Sx, Sy):
    Sx = 128 - (len(obj[0]) + abs(vx))
    Sy = 64 - (len(obj) + abs(vy))
    if x >= Sx:
        vx = -vx
    if x <= abs(vx):
        vx = -vx
    if y >= Sy:
        vy = -vy
    if y <= abs(vy):
        vy = -vy
    return vx, vy
#Main event!
def main(obj, x, y, vx, vy, Sx, Sy):
    while True:
        displayObject(obj, x, y)
        time.sleep(1)
        eraseObject(obj, x, y)
        x, y = moveObject(obj, x, y, vx, vy)
        vx, vy = checkCollision(obj, x, y, vx, vy, Sx, Sy)

print("Welcome to the Ball game, folks!")
print("Prepare to enter coordinates for X and Y axis!")
x = int(input('Enter X coordinate (0,127): '))
y = int(input('Enter Y coordinate (0,63): '))
vx = vy = 8
Sx = 128
Sy = 64

main(ball, x, y, vx, vy, Sx, Sy)